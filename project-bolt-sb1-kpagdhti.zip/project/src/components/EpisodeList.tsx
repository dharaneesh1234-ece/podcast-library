import React from 'react';
import { Play, Pause, Download, MoreHorizontal, Clock, Calendar } from 'lucide-react';
import { Episode, Podcast } from '../types/podcast';

interface EpisodeListProps {
  episodes: Episode[];
  podcasts: Podcast[];
  currentEpisode: Episode | null;
  isPlaying: boolean;
  onPlay: (episode: Episode) => void;
  onPause: () => void;
}

export const EpisodeList: React.FC<EpisodeListProps> = ({
  episodes,
  podcasts,
  currentEpisode,
  isPlaying,
  onPlay,
  onPause,
}) => {
  const getPodcast = (podcastId: string) => podcasts.find(p => p.id === podcastId);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric', 
      year: 'numeric' 
    });
  };

  return (
    <div className="space-y-4">
      {episodes.map((episode) => {
        const podcast = getPodcast(episode.podcastId);
        const isCurrentEpisode = currentEpisode?.id === episode.id;
        const isCurrentlyPlaying = isCurrentEpisode && isPlaying;

        return (
          <div
            key={episode.id}
            className={`bg-white rounded-lg border p-4 hover:shadow-md transition-all duration-200 ${
              isCurrentEpisode ? 'border-indigo-200 bg-indigo-50' : 'border-gray-200'
            }`}
          >
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0">
                <img
                  src={podcast?.artwork}
                  alt={podcast?.title}
                  className="w-16 h-16 rounded-lg object-cover"
                />
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-gray-900 text-base leading-tight mb-1">
                      {episode.title}
                    </h3>
                    <p className="text-sm text-gray-600">{podcast?.title}</p>
                  </div>
                  <button className="p-1 text-gray-400 hover:text-gray-600 transition-colors duration-200">
                    <MoreHorizontal className="w-5 h-5" />
                  </button>
                </div>

                <p className="text-gray-600 text-sm line-clamp-2 mb-3 leading-relaxed">
                  {episode.description}
                </p>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4 text-sm text-gray-500">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      <span>{formatDate(episode.publishDate)}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      <span>{episode.duration}</span>
                    </div>
                    {episode.played && (
                      <span className="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs font-medium">
                        Played
                      </span>
                    )}
                    {episode.downloaded && (
                      <Download className="w-4 h-4 text-blue-600" />
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => isCurrentlyPlaying ? onPause() : onPlay(episode)}
                      className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                        isCurrentEpisode
                          ? 'bg-indigo-600 text-white hover:bg-indigo-700'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      {isCurrentlyPlaying ? (
                        <Pause className="w-4 h-4" />
                      ) : (
                        <Play className="w-4 h-4 ml-0.5" />
                      )}
                      <span className="text-sm">
                        {isCurrentlyPlaying ? 'Pause' : 'Play'}
                      </span>
                    </button>
                  </div>
                </div>

                {episode.progress > 0 && episode.progress < 100 && (
                  <div className="mt-3">
                    <div className="flex justify-between text-xs text-gray-500 mb-1">
                      <span>{episode.progress}% complete</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-1">
                      <div
                        className="bg-indigo-600 h-1 rounded-full transition-all duration-300"
                        style={{ width: `${episode.progress}%` }}
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};