import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, Repeat, Shuffle, Heart } from 'lucide-react';
import { Episode, Podcast, PlaybackState } from '../types/podcast';

interface AudioPlayerProps {
  currentEpisode: Episode | null;
  podcast: Podcast | null;
  playbackState: PlaybackState;
  onPlayPause: () => void;
  onSeek: (time: number) => void;
  onVolumeChange: (volume: number) => void;
}

export const AudioPlayer: React.FC<AudioPlayerProps> = ({
  currentEpisode,
  podcast,
  playbackState,
  onPlayPause,
  onSeek,
  onVolumeChange,
}) => {
  const [isMuted, setIsMuted] = useState(false);
  const [isShuffled, setIsShuffled] = useState(false);
  const [repeatMode, setRepeatMode] = useState(0); // 0: no repeat, 1: repeat all, 2: repeat one
  const progressRef = useRef<HTMLDivElement>(null);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (progressRef.current && playbackState.duration > 0) {
      const rect = progressRef.current.getBoundingClientRect();
      const clickX = e.clientX - rect.left;
      const percentage = clickX / rect.width;
      const newTime = percentage * playbackState.duration;
      onSeek(newTime);
    }
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
    onVolumeChange(isMuted ? playbackState.volume : 0);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const volume = parseFloat(e.target.value);
    onVolumeChange(volume);
    setIsMuted(volume === 0);
  };

  if (!currentEpisode || !podcast) {
    return null;
  }

  const progress = playbackState.duration > 0 ? (playbackState.currentTime / playbackState.duration) * 100 : 0;

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg z-50">
      <div className="flex items-center justify-between px-6 py-4">
        {/* Episode Info */}
        <div className="flex items-center gap-4 flex-1 min-w-0">
          <img
            src={podcast.artwork}
            alt={podcast.title}
            className="w-14 h-14 rounded-lg object-cover flex-shrink-0"
          />
          <div className="flex-1 min-w-0">
            <h4 className="font-semibold text-gray-900 text-sm truncate">
              {currentEpisode.title}
            </h4>
            <p className="text-gray-600 text-xs truncate">{podcast.title}</p>
          </div>
          <button className="text-gray-400 hover:text-red-500 transition-colors duration-200">
            <Heart className="w-5 h-5" />
          </button>
        </div>

        {/* Playback Controls */}
        <div className="flex flex-col items-center gap-2 flex-1 max-w-lg">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsShuffled(!isShuffled)}
              className={`p-2 rounded-full transition-colors duration-200 ${
                isShuffled ? 'text-indigo-600 bg-indigo-100' : 'text-gray-400 hover:text-gray-600'
              }`}
            >
              <Shuffle className="w-4 h-4" />
            </button>

            <button className="p-2 text-gray-400 hover:text-gray-600 transition-colors duration-200">
              <SkipBack className="w-5 h-5" />
            </button>

            <button
              onClick={onPlayPause}
              className="bg-indigo-600 text-white p-3 rounded-full hover:bg-indigo-700 transition-colors duration-200"
            >
              {playbackState.isPlaying ? (
                <Pause className="w-6 h-6" />
              ) : (
                <Play className="w-6 h-6 ml-1" />
              )}
            </button>

            <button className="p-2 text-gray-400 hover:text-gray-600 transition-colors duration-200">
              <SkipForward className="w-5 h-5" />
            </button>

            <button
              onClick={() => setRepeatMode((repeatMode + 1) % 3)}
              className={`p-2 rounded-full transition-colors duration-200 ${
                repeatMode > 0 ? 'text-indigo-600 bg-indigo-100' : 'text-gray-400 hover:text-gray-600'
              }`}
            >
              <Repeat className="w-4 h-4" />
              {repeatMode === 2 && (
                <span className="absolute -top-1 -right-1 w-2 h-2 bg-indigo-600 rounded-full"></span>
              )}
            </button>
          </div>

          {/* Progress Bar */}
          <div className="flex items-center gap-3 w-full">
            <span className="text-xs text-gray-500 w-10 text-right">
              {formatTime(playbackState.currentTime)}
            </span>
            <div
              ref={progressRef}
              className="flex-1 h-2 bg-gray-200 rounded-full cursor-pointer group"
              onClick={handleProgressClick}
            >
              <div
                className="h-full bg-indigo-600 rounded-full relative transition-all duration-150"
                style={{ width: `${progress}%` }}
              >
                <div className="absolute -right-1 top-1/2 transform -translate-y-1/2 w-3 h-3 bg-indigo-600 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-200"></div>
              </div>
            </div>
            <span className="text-xs text-gray-500 w-10">
              {formatTime(playbackState.duration)}
            </span>
          </div>
        </div>

        {/* Volume Controls */}
        <div className="flex items-center gap-3 flex-1 justify-end">
          <button onClick={toggleMute} className="text-gray-400 hover:text-gray-600 transition-colors duration-200">
            {isMuted || playbackState.volume === 0 ? (
              <VolumeX className="w-5 h-5" />
            ) : (
              <Volume2 className="w-5 h-5" />
            )}
          </button>
          <input
            type="range"
            min="0"
            max="1"
            step="0.01"
            value={isMuted ? 0 : playbackState.volume}
            onChange={handleVolumeChange}
            className="w-20 h-1 bg-gray-200 rounded-full appearance-none cursor-pointer slider"
          />
        </div>
      </div>
    </div>
  );
};