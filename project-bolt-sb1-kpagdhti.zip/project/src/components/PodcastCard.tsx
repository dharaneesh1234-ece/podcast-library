import React from 'react';
import { Play, Plus, Check, Download, MoreHorizontal } from 'lucide-react';
import { Podcast } from '../types/podcast';

interface PodcastCardProps {
  podcast: Podcast;
  onSubscribe: (podcastId: string) => void;
  onPlay: (podcastId: string) => void;
}

export const PodcastCard: React.FC<PodcastCardProps> = ({ podcast, onSubscribe, onPlay }) => {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden group hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
      <div className="relative">
        <img
          src={podcast.artwork}
          alt={podcast.title}
          className="w-full h-48 object-cover"
        />
        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-300 flex items-center justify-center">
          <button
            onClick={() => onPlay(podcast.id)}
            className="bg-indigo-600 text-white p-3 rounded-full opacity-0 group-hover:opacity-100 transform scale-75 group-hover:scale-100 transition-all duration-300 hover:bg-indigo-700"
          >
            <Play className="w-6 h-6 ml-1" />
          </button>
        </div>
        <div className="absolute top-3 right-3">
          <button className="bg-white bg-opacity-90 backdrop-blur-sm p-2 rounded-full hover:bg-opacity-100 transition-all duration-200">
            <MoreHorizontal className="w-4 h-4 text-gray-700" />
          </button>
        </div>
      </div>

      <div className="p-5">
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-gray-900 text-lg leading-tight mb-1 line-clamp-2">
              {podcast.title}
            </h3>
            <p className="text-gray-600 text-sm">{podcast.author}</p>
          </div>
        </div>

        <p className="text-gray-600 text-sm line-clamp-2 mb-4 leading-relaxed">
          {podcast.description}
        </p>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4 text-sm text-gray-500">
            <span className="bg-gray-100 px-2 py-1 rounded-full text-xs font-medium">
              {podcast.category}
            </span>
            <span>{podcast.episodeCount} episodes</span>
          </div>

          <div className="flex items-center gap-2">
            <button className="p-2 text-gray-400 hover:text-gray-600 transition-colors duration-200">
              <Download className="w-4 h-4" />
            </button>
            <button
              onClick={() => onSubscribe(podcast.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                podcast.subscribed
                  ? 'bg-green-100 text-green-700 hover:bg-green-200'
                  : 'bg-indigo-600 text-white hover:bg-indigo-700'
              }`}
            >
              {podcast.subscribed ? (
                <>
                  <Check className="w-4 h-4" />
                  <span className="text-sm">Subscribed</span>
                </>
              ) : (
                <>
                  <Plus className="w-4 h-4" />
                  <span className="text-sm">Subscribe</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};