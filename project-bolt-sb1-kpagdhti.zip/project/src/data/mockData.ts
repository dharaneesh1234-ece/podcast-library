import { Podcast, Episode } from '../types/podcast';

export const mockPodcasts: Podcast[] = [
  {
    id: '1',
    title: 'Tech Talk Daily',
    author: 'Sarah Johnson',
    description: 'Daily insights into the latest technology trends, startup news, and innovation stories from Silicon Valley and beyond.',
    artwork: 'https://images.pexels.com/photos/267350/pexels-photo-267350.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'Technology',
    episodeCount: 245,
    subscribed: true,
    lastUpdated: '2025-01-20'
  },
  {
    id: '2',
    title: 'Creative Minds',
    author: 'Alex Chen',
    description: 'Exploring creativity, design thinking, and artistic processes with leading creatives from around the world.',
    artwork: 'https://images.pexels.com/photos/3747468/pexels-photo-3747468.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'Arts & Design',
    episodeCount: 128,
    subscribed: true,
    lastUpdated: '2025-01-19'
  },
  {
    id: '3',
    title: 'Business Breakthrough',
    author: 'Michael Roberts',
    description: 'Strategic insights and success stories from entrepreneurs, CEOs, and business leaders who are changing the world.',
    artwork: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'Business',
    episodeCount: 89,
    subscribed: false,
    lastUpdated: '2025-01-18'
  },
  {
    id: '4',
    title: 'Science Simplified',
    author: 'Dr. Emily Watson',
    description: 'Making complex scientific concepts accessible to everyone through engaging stories and expert interviews.',
    artwork: 'https://images.pexels.com/photos/2280571/pexels-photo-2280571.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'Science',
    episodeCount: 156,
    subscribed: true,
    lastUpdated: '2025-01-17'
  },
  {
    id: '5',
    title: 'History Uncovered',
    author: 'James Patterson',
    description: 'Diving deep into fascinating historical events, forgotten stories, and the people who shaped our world.',
    artwork: 'https://images.pexels.com/photos/1482476/pexels-photo-1482476.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'History',
    episodeCount: 203,
    subscribed: false,
    lastUpdated: '2025-01-16'
  },
  {
    id: '6',
    title: 'Wellness Journey',
    author: 'Lisa Martinez',
    description: 'Your guide to mental health, physical wellness, and living your best life through practical tips and expert advice.',
    artwork: 'https://images.pexels.com/photos/3820339/pexels-photo-3820339.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'Health & Wellness',
    episodeCount: 167,
    subscribed: true,
    lastUpdated: '2025-01-15'
  }
];

export const mockEpisodes: Episode[] = [
  {
    id: 'e1',
    podcastId: '1',
    title: 'The Future of AI: Opportunities and Challenges',
    description: 'A deep dive into artificial intelligence developments, discussing both the incredible opportunities and the challenges we face as AI becomes more integrated into our daily lives.',
    duration: '45:32',
    publishDate: '2025-01-20',
    audioUrl: '',
    played: false,
    progress: 0,
    downloaded: true
  },
  {
    id: 'e2',
    podcastId: '1',
    title: 'Startup Funding Trends in 2025',
    description: 'Analyzing the latest trends in startup funding, venture capital movements, and what entrepreneurs need to know to secure investment in today\'s market.',
    duration: '38:15',
    publishDate: '2025-01-19',
    audioUrl: '',
    played: true,
    progress: 100,
    downloaded: false
  },
  {
    id: 'e3',
    podcastId: '2',
    title: 'Design Systems That Scale',
    description: 'How to build design systems that grow with your organization, featuring insights from design leaders at major tech companies.',
    duration: '52:18',
    publishDate: '2025-01-19',
    audioUrl: '',
    played: false,
    progress: 25,
    downloaded: true
  },
  {
    id: 'e4',
    podcastId: '2',
    title: 'The Psychology of Color in Branding',
    description: 'Understanding how color choices impact brand perception and consumer behavior, with practical examples from successful brands.',
    duration: '41:27',
    publishDate: '2025-01-17',
    audioUrl: '',
    played: true,
    progress: 100,
    downloaded: false
  },
  {
    id: 'e5',
    podcastId: '4',
    title: 'Climate Change: The Latest Research',
    description: 'Breaking down the most recent climate science findings and what they mean for our planet\'s future.',
    duration: '49:33',
    publishDate: '2025-01-17',
    audioUrl: '',
    played: false,
    progress: 0,
    downloaded: false
  },
  {
    id: 'e6',
    podcastId: '6',
    title: 'Mindfulness in the Digital Age',
    description: 'Practical strategies for maintaining mental wellness and mindfulness practices in our hyper-connected world.',
    duration: '36:42',
    publishDate: '2025-01-15',
    audioUrl: '',
    played: false,
    progress: 15,
    downloaded: true
  }
];