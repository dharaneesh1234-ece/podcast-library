export interface Podcast {
  id: string;
  title: string;
  author: string;
  description: string;
  artwork: string;
  category: string;
  episodeCount: number;
  subscribed: boolean;
  lastUpdated: string;
}

export interface Episode {
  id: string;
  podcastId: string;
  title: string;
  description: string;
  duration: string;
  publishDate: string;
  audioUrl: string;
  played: boolean;
  progress: number;
  downloaded: boolean;
}

export interface PlaybackState {
  currentEpisode: Episode | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
}