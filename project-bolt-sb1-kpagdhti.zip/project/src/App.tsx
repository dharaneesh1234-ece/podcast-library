import React, { useState, useCallback } from 'react';
import { Search } from 'lucide-react';
import { Sidebar } from './components/Sidebar';
import { PodcastCard } from './components/PodcastCard';
import { EpisodeList } from './components/EpisodeList';
import { AudioPlayer } from './components/AudioPlayer';
import { mockPodcasts, mockEpisodes } from './data/mockData';
import { Podcast, Episode, PlaybackState } from './types/podcast';

function App() {
  const [activeView, setActiveView] = useState('home');
  const [podcasts, setPodcasts] = useState<Podcast[]>(mockPodcasts);
  const [episodes] = useState<Episode[]>(mockEpisodes);
  const [searchQuery, setSearchQuery] = useState('');
  const [playbackState, setPlaybackState] = useState<PlaybackState>({
    currentEpisode: null,
    isPlaying: false,
    currentTime: 0,
    duration: 0,
    volume: 0.8,
  });

  const subscribedPodcasts = podcasts.filter(p => p.subscribed);
  const subscribedEpisodes = episodes.filter(e => 
    subscribedPodcasts.some(p => p.id === e.podcastId)
  ).sort((a, b) => new Date(b.publishDate).getTime() - new Date(a.publishDate).getTime());

  const downloadedEpisodes = episodes.filter(e => e.downloaded);

  const filteredPodcasts = podcasts.filter(podcast =>
    podcast.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    podcast.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
    podcast.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSubscribe = useCallback((podcastId: string) => {
    setPodcasts(prev => prev.map(podcast => 
      podcast.id === podcastId 
        ? { ...podcast, subscribed: !podcast.subscribed }
        : podcast
    ));
  }, []);

  const handlePlayEpisode = useCallback((episode: Episode) => {
    setPlaybackState(prev => ({
      ...prev,
      currentEpisode: episode,
      isPlaying: true,
      currentTime: 0,
      duration: 2700, // Mock duration (45 minutes)
    }));
  }, []);

  const handlePlayPodcast = useCallback((podcastId: string) => {
    const podcastEpisodes = episodes.filter(e => e.podcastId === podcastId);
    if (podcastEpisodes.length > 0) {
      const latestEpisode = podcastEpisodes.sort((a, b) => 
        new Date(b.publishDate).getTime() - new Date(a.publishDate).getTime()
      )[0];
      handlePlayEpisode(latestEpisode);
    }
  }, [episodes, handlePlayEpisode]);

  const handlePlayPause = useCallback(() => {
    setPlaybackState(prev => ({
      ...prev,
      isPlaying: !prev.isPlaying,
    }));
  }, []);

  const handleSeek = useCallback((time: number) => {
    setPlaybackState(prev => ({
      ...prev,
      currentTime: time,
    }));
  }, []);

  const handleVolumeChange = useCallback((volume: number) => {
    setPlaybackState(prev => ({
      ...prev,
      volume,
    }));
  }, []);

  const getCurrentPodcast = () => {
    if (!playbackState.currentEpisode) return null;
    return podcasts.find(p => p.id === playbackState.currentEpisode?.podcastId) || null;
  };

  const renderContent = () => {
    switch (activeView) {
      case 'search':
        return (
          <div className="space-y-6">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search for podcasts, episodes, or creators..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-white border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-gray-900 placeholder-gray-500"
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredPodcasts.map((podcast) => (
                <PodcastCard
                  key={podcast.id}
                  podcast={podcast}
                  onSubscribe={handleSubscribe}
                  onPlay={handlePlayPodcast}
                />
              ))}
            </div>
          </div>
        );

      case 'library':
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900">Your Library</h2>
              <p className="text-gray-600">{subscribedPodcasts.length} subscriptions</p>
            </div>
            
            {subscribedPodcasts.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {subscribedPodcasts.map((podcast) => (
                  <PodcastCard
                    key={podcast.id}
                    podcast={podcast}
                    onSubscribe={handleSubscribe}
                    onPlay={handlePlayPodcast}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-500 text-lg">No subscriptions yet</p>
                <p className="text-gray-400 mt-2">Discover new podcasts to start building your library</p>
              </div>
            )}

            {subscribedEpisodes.length > 0 && (
              <div className="mt-8">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Recent Episodes</h3>
                <EpisodeList
                  episodes={subscribedEpisodes.slice(0, 5)}
                  podcasts={podcasts}
                  currentEpisode={playbackState.currentEpisode}
                  isPlaying={playbackState.isPlaying}
                  onPlay={handlePlayEpisode}
                  onPause={() => setPlaybackState(prev => ({ ...prev, isPlaying: false }))}
                />
              </div>
            )}
          </div>
        );

      case 'downloads':
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900">Downloads</h2>
              <p className="text-gray-600">{downloadedEpisodes.length} episodes</p>
            </div>
            
            {downloadedEpisodes.length > 0 ? (
              <EpisodeList
                episodes={downloadedEpisodes}
                podcasts={podcasts}
                currentEpisode={playbackState.currentEpisode}
                isPlaying={playbackState.isPlaying}
                onPlay={handlePlayEpisode}
                onPause={() => setPlaybackState(prev => ({ ...prev, isPlaying: false }))}
              />
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-500 text-lg">No downloaded episodes</p>
                <p className="text-gray-400 mt-2">Download episodes for offline listening</p>
              </div>
            )}
          </div>
        );

      case 'favorites':
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900">Favorites</h2>
            <div className="text-center py-12">
              <p className="text-gray-500 text-lg">No favorites yet</p>
              <p className="text-gray-400 mt-2">Like episodes to add them to your favorites</p>
            </div>
          </div>
        );

      case 'settings':
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900">Settings</h2>
            <div className="bg-white rounded-xl border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Playback Settings</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-gray-700">Auto-play next episode</span>
                  <input type="checkbox" className="toggle" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-700">Download over cellular</span>
                  <input type="checkbox" className="toggle" />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-700">Skip intro/outro</span>
                  <input type="checkbox" className="toggle" defaultChecked />
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return (
          <div className="space-y-8">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Welcome back!</h2>
              <p className="text-gray-600">Discover your next favorite podcast</p>
            </div>

            {subscribedEpisodes.length > 0 && (
              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Continue Listening</h3>
                <EpisodeList
                  episodes={subscribedEpisodes.slice(0, 3)}
                  podcasts={podcasts}
                  currentEpisode={playbackState.currentEpisode}
                  isPlaying={playbackState.isPlaying}
                  onPlay={handlePlayEpisode}
                  onPause={() => setPlaybackState(prev => ({ ...prev, isPlaying: false }))}
                />
              </div>
            )}

            <div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Trending Podcasts</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {podcasts.slice(0, 6).map((podcast) => (
                  <PodcastCard
                    key={podcast.id}
                    podcast={podcast}
                    onSubscribe={handleSubscribe}
                    onPlay={handlePlayPodcast}
                  />
                ))}
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <Sidebar activeView={activeView} onViewChange={setActiveView} />
      
      <main className="flex-1 flex flex-col">
        <div className="flex-1 p-8 pb-32 overflow-y-auto">
          {renderContent()}
        </div>
        
        <AudioPlayer
          currentEpisode={playbackState.currentEpisode}
          podcast={getCurrentPodcast()}
          playbackState={playbackState}
          onPlayPause={handlePlayPause}
          onSeek={handleSeek}
          onVolumeChange={handleVolumeChange}
        />
      </main>
    </div>
  );
}

export default App;